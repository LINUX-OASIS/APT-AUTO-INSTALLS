#include <stdio.h>

int main(int argc, char **argv)
{
	printf("give me a bottle of rum!\n");
	return 0;
}
