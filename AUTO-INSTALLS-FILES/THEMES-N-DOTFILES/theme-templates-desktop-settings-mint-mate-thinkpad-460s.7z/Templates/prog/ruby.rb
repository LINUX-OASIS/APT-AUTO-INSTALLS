#!/usr/bin/ruby

puts "give me a bottle of rum!"
