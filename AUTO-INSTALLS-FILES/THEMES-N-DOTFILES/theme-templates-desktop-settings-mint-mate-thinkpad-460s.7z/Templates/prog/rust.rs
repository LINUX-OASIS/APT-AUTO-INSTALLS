fn main() {
    println!("give me a bottle of rum!");
}
