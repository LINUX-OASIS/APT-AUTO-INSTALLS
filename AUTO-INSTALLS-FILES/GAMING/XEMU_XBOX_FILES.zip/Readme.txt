Links in case you want them.

https://github.com/mborgerson/xemu/wiki#hard-disk-drive-image 
(Go to Getting Started section on this page for more instructions.)

https://github.com/mborgerson/xemu/releases 
(Download page for XEMU emulator.)

https://downloads.diodematrix.com/homebrew/xbins/Console%20Based%20Applications/bios/complex/
(Download page for Complex BIOS files.)

https://github.com/mborgerson/xemu-hdd-image/releases/latest/download/xbox_hdd.qcow2.zip
(Download link for Xbox HDD image)

http://emulation.gametechwiki.com/index.php/Emulator_Files
(Download page for Boot ROM image) (On page it's under Microsoft_Xbox_File Types download link "BIOS files".)
--------------------------------------------------------------------------------------------------------------

The XEMU FILES folder has the extra files that XEMU requires to run.

Contents of folder:

BIOS: Complex BIOS both work. (Don't know which is better to use.)

Boot ROM image: MCPX_1.0

Pre-built Xbox HDD image: Properly-formatted hard disk drive image.
-------------------------------------------------------------------------------------------------------------