hashcat-utils
==============

Hashcat-utils are a set of small utilities that are useful in advanced password cracking

Brief description
--------------

They all are packed into multiple stand-alone binaries.

All of these utils are designed to execute only one specific function.

Since they all work with STDIN and STDOUT you can group them into chains.

Detailed description
--------------

See the hashcat wiki page of hashcat-utils: https://hashcat.net/wiki/doku.php?id=hashcat_utils

Compile
--------------

Simply run make

  then,  you can optionally..DONT RECOMEND DOING THIS, just copy cap2hccapx, since its the only on youll be using. copy to the linux bin folder ... without the .bin file extension

Binary distribution
--------------

Binaries for Linux, Windows and OSX: https://github.com/hashcat/hashcat-utils/releases
