
#ifndef WIHOTSPOT_UI_QR
#define WIHOTSPOT_UI_QR


#include <gtk/gtk.h>


void open_qr(GtkWidget *widget, gpointer window,char* image_path);

#endif