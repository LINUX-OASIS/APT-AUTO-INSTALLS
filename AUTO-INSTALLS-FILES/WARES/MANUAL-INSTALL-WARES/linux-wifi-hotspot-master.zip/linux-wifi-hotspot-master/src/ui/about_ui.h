
#ifndef WIHOTSPOT_UI_ABOUT
#define WIHOTSPOT_UI_ABOUT


#include <gtk/gtk.h>


void show_info(GtkWidget *widget, gpointer window);

#endif